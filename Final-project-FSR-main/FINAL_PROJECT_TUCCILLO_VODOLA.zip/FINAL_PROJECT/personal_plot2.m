function h = personal_plot2(x, y1, y2, y3, x_label_latex, y_label_latex, pdf_name, plot_title, legend_labels)
    % Impostazioni per la visualizzazione dei testi in LaTeX
    set(0, 'DefaultTextInterpreter', 'latex')
    set(0, 'DefaultLegendInterpreter', 'latex')
    set(0, 'DefaultAxesTickLabelInterpreter', 'latex')
    lw = 2; % Line width

    % Creazione della figura
    h = figure('Renderer', 'painters', 'Position', [10 10 900 500]);
    removeToolbarExplorationButtons(h)

    % Plot delle tre grandezze con colori diversi
    plot(x, y1, 'Linewidth', lw, 'Color', [0, 0, 1]); % Blu
    hold on;
    plot(x, y2, 'Linewidth', lw, 'Color', [1, 0, 0]); % Rosso
    plot(x, y3, 'Linewidth', lw, 'Color', [0, 1, 0]); % Verde
    hold off;

    % Impostazione dei limiti dell'asse x
    xlim([x(1) x(end)])

    % Etichette degli assi
    xlabel(x_label_latex)
    ylabel(y_label_latex)

    % Titolo del grafico
    title(plot_title)

    % Legenda
    legend(legend_labels, 'Location', 'Best')

    % Impostazioni dei caratteri
    set(gca, 'FontSize', 18);

    % Griglia e bordo
    grid on
    box on

    % Impostazione del colore di sfondo della figura
    set(gcf, 'color', 'w');

    % Esportazione del grafico come file PDF
    exportgraphics(h, pdf_name);
end
