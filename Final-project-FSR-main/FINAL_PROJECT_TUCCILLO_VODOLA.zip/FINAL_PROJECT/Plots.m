clc
close all
clear all


simulink = sim("AISMC.slx");

time = simulink.tout;
err_eta = simulink.out.signals.values(1:3,:);
err_eta_dot = simulink.out.signals.values(4:6,:);
err_p = simulink.out.signals.values(7:9,:);
err_p_dot = simulink.out.signals.values(10:12,:);
uT = simulink.out.signals.values(13,:);
tau_b = simulink.out.signals.values(14:16,:);
p = simulink.out.signals.values(17:19,:);
p_dot = simulink.out.signals.values(20:22,:);
p_ddot = simulink.out.signals.values(23:25,:);
eta = simulink.out.signals.values(26:28,:);
eta_dot = simulink.out.signals.values(29:31,:);
eta_ddot = simulink.out.signals.values(32:34,:);
d_eta = simulink.out.signals.values(35:37,:);
d_eta_dot = simulink.out.signals.values(38:40,:);
d_eta_ddot = simulink.out.signals.values(41:43,:);
dis_ang = simulink.out.signals.values(44:46,:);
tau_hat = simulink.out.signals.values(47:49,:);
es_err_ang = simulink.out.signals.values(50:52,:);
dis_pos = simulink.out.signals.values(53:55,:);
fe_hat = simulink.out.signals.values(56:58,:);
es_err_pos = simulink.out.signals.values(59:61,:);
sigma_eta = simulink.out.signals.values(62:64,:);
sigma_p = simulink.out.signals.values(65:67,:);
mot_vel=simulink.out.signals.values(68:71,:);
mass_es=simulink.out.signals.values(72,:);
%% reference and measured trajectory comparison
figure
plot3(p_d1(1,:),p_d1(2,:),p_d1(3,:),'b','LineWidth',2);
hold on
plot3(x_d2,y_d2,z_d2,'m','LineWidth',2);
hold on
plot3(p_d3(1,:),p_d3(2,:),p_d3(3,:),'r','LineWidth',2);
set(gca,'ZDir','reverse')
set(gca,'YDir','reverse')
axis('equal')
grid
xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
hold off
% Linear errors plot
vec_time = {time, time, time};
err = {err_p(1,:), err_p(2,:), err_p(3,:)};

x_label_latex = {'time [s]', 'time [s]', 'time [s]'};
y_label_latex = {'$e_x$ [m]', '$e_y$ [m]', '$e_z$ [m]'};
subplot_titles = {'Position Error on $x$', 'Position Error on $y$', 'Position Error on $z$'};
pdf_name = 'Linear Position Errors.pdf';
num_subplot = 3;
h = personal_subplot(vec_time, err, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

dot_err = {err_p_dot(1,:), err_p_dot(2,:), err_p_dot(3,:)};
y_label_latex = {'$\dot{e}_x$ [m/s]', '$\dot{e}_y$ [m/s]', '$\dot{e}_z$ [m/s]'};
subplot_titles = {'Velocity Error on $x$', 'Velocity Error on $y$', 'Velocity Error on $z$'};
pdf_name = 'Linear Velocity Errors.pdf';
h = personal_subplot(vec_time, dot_err, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% Angular errors plot
ang_err = {err_eta(1,:), err_eta(2,:), err_eta(3,:)};
y_label_latex = {'$e_\phi$ [rad]', '$e_\theta$ [rad]', '$e_\psi$ [rad]'};
subplot_titles = {'Roll Error', 'Pitch Error', 'Yaw Error'};
pdf_name = 'Angular Errors.pdf';
h = personal_subplot(vec_time, ang_err, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

w_err = {err_eta_dot(1,:), err_eta_dot(2,:), err_eta_dot(3,:)};
y_label_latex = {'$e_{\dot{\phi}}$ [rad/s]', '$e_{\dot{\theta}}$ [rad/s]', '$e_{\dot{\psi}}$ [rad/s]'};
subplot_titles = {'Roll First Derivative Error', 'Pitch First Derivative Error', 'Yaw First Derivative Error'};
pdf_name = 'Angular velocity Errors.pdf';
h = personal_subplot(vec_time, w_err, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% pose
position = {p(1,:), p(2,:), p(3,:)};
y_label_latex = {'$x$ [m]', '$y$ [m]', '$z$ [m]'};
subplot_titles = {'Trajectory along $x$', 'Trajectory along $y$', 'Trajectory along $z$'};
pdf_name = 'Position.pdf';
h = personal_subplot(vec_time, position, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

EA = {eta(1,:), eta(2,:), eta(3,:)};
y_label_latex = {'$\phi$ [rad]', '$\theta$ [rad]', '$\psi$ [rad]'};
subplot_titles = {'Roll', 'Pitch', 'Yaw'};
pdf_name = 'RPY.pdf';
h = personal_subplot(vec_time, EA, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% control actions
input = {tau_b(1,:), tau_b(2,:), tau_b(3,:), uT(:)};
t2 = {time, time, time, time};
x_label_latex = {'time [s]', 'time [s]', 'time [s]', 'time [s]'};
y_label_latex = {'$\tau_x$ [Nm]', '$\tau_y$ [Nm]', '$\tau_z$ [Nm]', '$u_T$ [N]'};
subplot_titles = {'Torque around $x$', 'Torque around $y$', 'Torque around $z$', 'Total thrust'};
pdf_name = 'Control inputs.pdf';
h = personal_subplot2(t2, input, x_label_latex, y_label_latex, pdf_name, 4, 1, subplot_titles);

% motor velocity
mot = {mot_vel(1,:), mot_vel(2,:), mot_vel(3,:), mot_vel(4,:)};
t2 = {time, time, time, time};
x_label_latex = {'time [s]', 'time [s]', 'time [s]', 'time [s]'};
y_label_latex = {'$\omega_1$ [rad/s]', '$\omega_2$ [rad/s]', '$\omega_3$ [rad/s]', '$\omega_4$ [rad/s]'};
subplot_titles = {'Motor velocity 1', 'Motor velocity 2', 'Motor velocity 3', 'Motor velocity 4'};
pdf_name = 'motor velocity.pdf';
h = personal_subplot2(t2, mot, x_label_latex, y_label_latex, pdf_name, 4, 1, subplot_titles);

% velocities
vel = {p_dot(1,:), p_dot(2,:), p_dot(3,:)};
y_label_latex = {'$\dot{x}$ [m/s]', '$\dot{y}$ [m/s]', '$\dot{z}$ [m/s]'};
subplot_titles = {'Velocity along $x$', 'Velocity along $y$', 'Velocity along $z$'};
pdf_name = 'Linear velocities.pdf';
h = personal_subplot(vec_time, vel, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

omega = {eta_dot(1,:), eta_dot(2,:), eta_dot(3,:)};
y_label_latex = {'$\dot{\phi}$ [rad/s]', '$\dot{\theta}$ [rad/s]', '$\dot{\psi}$ [rad/s]'};
subplot_titles = {'Roll First Derivative', 'Pitch First Derivative', 'Yaw First Derivative'};
pdf_name = 'Angular velocities.pdf';
h = personal_subplot(vec_time, omega, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% accelerations
acc = {p_ddot(1,:), p_ddot(2,:), p_ddot(3,:)};
y_label_latex = {'$\ddot{x}$ [m/$s^2$]', '$\ddot{y}$ [m/$s^2$]', '$\ddot{z}$ [m/$s^2$]'};
subplot_titles = {'Acceleration along $x$', 'Acceleration along $y$', 'Acceleration along $z$'};
pdf_name = 'Linear acceleration.pdf';
h = personal_subplot(vec_time, acc, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

omega_do = {eta_ddot(1,:), eta_ddot(2,:), eta_ddot(3,:)};
y_label_latex = {'$\ddot{\phi}$ [rad/$s^2$]', '$\ddot{\theta}$ [rad/$s^2$]', '$\ddot{\psi}$ [rad/$s^2$]'};
subplot_titles = {'Roll Second Derivative', 'Pitch Second Derivative', 'Yaw Second Derivative'};
pdf_name = 'Angular accelerations.pdf';
h = personal_subplot(vec_time, omega_do, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% desired eta
d_eta_plot = {d_eta(1,:), d_eta(2,:), d_eta(3,:)};
y_label_latex = {'$\phi_d$ [rad]', '$\theta_d$ [rad]', '$\psi_d$ [rad]'};
subplot_titles = {'Desired Roll', 'Desired Pitch', 'Desired Yaw'};
pdf_name = 'Desired Eta.pdf';
h = personal_subplot(vec_time, d_eta_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% desired eta dot
d_eta_dot_plot = {d_eta_dot(1,:), d_eta_dot(2,:), d_eta_dot(3,:)};
y_label_latex = {'$\dot{\phi}_d$ [rad/s]', '$$\dot{\theta}_d [rad/s]$', '$$\dot{\psi}_d$ [rad/s]'};
subplot_titles = {'Desired roll vel', 'Desired pitch vel', 'Desired yaw vel'};
pdf_name = 'Desired Eta Dot.pdf';
h = personal_subplot(vec_time, d_eta_dot_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% desired eta ddot
d_eta_ddot_plot = {d_eta_ddot(1,:), d_eta_ddot(2,:), d_eta_ddot(3,:)};
y_label_latex = {'$\ddot{\phi}_d [rad/s^2]$ ', '$\ddot{\theta}_d [rad/s^2]$', '$\ddot{\psi}_d [rad/s^2]$'};
subplot_titles = {'Desired roll acc', 'Desired pitch acc', 'Desired yaw acc'};
pdf_name = 'Desired Eta Ddot.pdf';
h = personal_subplot(vec_time, d_eta_ddot_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% % disturbance angular
% dis_ang_plot = {dis_ang(1,:), dis_ang(2,:), dis_ang(3,:)};
% y_label_latex = {'$dis_{ang x}$ [rad/s^2]', '$dis_{ang y}$ [rad/s^2]', '$dis_{ang z}$ [rad/s^2]'};
% subplot_titles = {'Disturbance angular x', 'Disturbance angular y', 'Disturbance angular z'};
% pdf_name = 'Disturbance Angular.pdf';
% h = personal_subplot(vec_time, dis_ang_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% tau_hat
tau_hat_plot = {tau_hat(1,:), tau_hat(2,:), tau_hat(3,:)};
y_label_latex = {'$\hat{\tau}_{e,x}$ [Nm]', '$\hat{\tau}_{e,y} [Nm]$', '$\hat{\tau}_{e,z}$ [Nm]'};
subplot_titles = {'Torque estimation around $x$','Torque estimation around $y$','Torque estimation around $z$'};
pdf_name = 'tau hat.pdf';
h = personal_subplot(vec_time, tau_hat_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% % estimated error angular
% es_err_ang_plot = {es_err_ang(1,:), es_err_ang(2,:), es_err_ang(3,:)};
% y_label_latex = {'$es_{err_{ang x}}$', '$es_{err_{ang y}}$', '$es_{err_{ang z}}$'};
% subplot_titles = {'Estimation angular error x', 'Estimation angular error y', 'Estimation angular error z'};
% pdf_name = 'Estimation Error Angular.pdf';
% h = personal_subplot(vec_time, es_err_ang_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% % disturbance position
% dis_pos_plot = {dis_pos(1,:), dis_pos(2,:), dis_pos(3,:)};
% y_label_latex = {'$dis_{pos x}$ [m/s^2]', '$dis_{pos y}$ [m/s^2]', '$dis_{pos z}$ [m/s^2]'};
% subplot_titles = {'Disturbance position x', 'Disturbance position y', 'Disturbance position z'};
% pdf_name = 'Disturbance Position.pdf';
% h = personal_subplot(vec_time, dis_pos_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% fe_hat
fe_hat_plot = {fe_hat(1,:), fe_hat(2,:), fe_hat(3,:)};
y_label_latex = {'$\hat{f}_{e,x}$ [N]', '$\hat{f}_{e,y}$ [N]', '$\hat{f}_{e,z}$ [N]'};
subplot_titles = {'Force estimation along $x$', 'Force estimation along $y$', 'Force estimation along $z$'};
pdf_name = 'fe hat.pdf';
h = personal_subplot(vec_time, fe_hat_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% mass
y_label_latex = {'mass [Kg]'};
plot_title = {'Mass estimation'};
pdf_name = 'mass_estimation.pdf';
h = personal_plot(time,mass_es,{'time [s]'}, y_label_latex, pdf_name,plot_title);

% % estimated error position
% es_err_pos_plot = {es_err_pos(1,:), es_err_pos(2,:), es_err_pos(3,:)};
% y_label_latex = {'$es_{err_{pos x}}$', '$es_{err_{pos y}}$', '$es_{err_{pos z}}$'};
% subplot_titles = {'Estimation error along x', 'Estimation error along y', 'Estimation error along z'};
% pdf_name = 'Estimated Error Position.pdf';
% h = personal_subplot(vec_time, es_err_pos_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);

% % sigma eta
% sigma_eta_plot = {sigma_eta(1,:), sigma_eta(2,:), sigma_eta(3,:)};
% y_label_latex = {'$\sigma_{\eta x}$', '$\sigma_{\eta y}$', '$\sigma_{\eta z}$'};
% subplot_titles = {'Sigma eta x', 'Sigma eta y', 'Sigma eta z'};
% pdf_name = 'Sigma Eta.pdf';
% h = personal_subplot(vec_time, sigma_eta_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);
% 
% % sigma p
% sigma_p_plot = {sigma_p(1,:), sigma_p(2,:), sigma_p(3,:)};
% y_label_latex = {'$\sigma_{p x}$', '$\sigma_{p y}$', '$\sigma_{p z}$'};
% subplot_titles = {'Sigma p x', 'Sigma p y', 'Sigma p z'};
% pdf_name = 'Sigma P.pdf';
% h = personal_subplot(vec_time, sigma_p_plot, x_label_latex, y_label_latex, pdf_name, num_subplot, subplot_titles);