%% computation of coefficients for the estimator
r=1; %better performances
k_but=coeff(r)*100; %larger bandwith
%% SAMPLING TIME
Ts=0.001;
%% ALLOCATION MATRIX
c_T=3.13e-5;
c_Q=7.5e-7;
l=0.23;
Alloc=[ c_T c_T c_T c_T; 0 -l*c_T 0 l*c_T; l*c_T 0 -l*c_T 0; -c_Q c_Q -c_Q c_Q ];
%% PLANNER
ttot=[40 20 40];
tdead=[15 10 25]; 
%s computations
[s1_d,dot_s1_d,ddot_s1_d,dddot_s1_d,tot_time1,t1]=planner3(Ts,0,ttot(1),tdead(1));
[s2_d,dot_s2_d,ddot_s2_d,dddot_s2_d,tot_time2,t2]=planner3(Ts,0,ttot(2),tdead(2));
[s3_d,dot_s3_d,ddot_s3_d,dddot_s3_d,tot_time3,t3]=planner3(Ts,0,ttot(3),tdead(3));

t=[t1 t1(end)+t2 t1(end)+t2(end)+t3];
%% initial conditions and parameters
x0=0; y0=0; z0=-2;
dot_x0=0; dot_y0=0; dot_z0=0;
alfa=6*pi;
alfa2=3*pi;
d=1.5;
radius1=0.5;
radius2=0.75;
%% yaw trajectory
[psi_d1,dot_psi_d1,ddot_psi_d1,dddot_psi_d1]=rectilinear_path_convex(s1_d,dot_s1_d,ddot_s1_d,dddot_s1_d,0,deg2rad(45));
[psi_d2,dot_psi_d2,ddot_psi_d2,dddot_psi_d2]=rectilinear_path_convex(s2_d,dot_s2_d,ddot_s2_d,dddot_s2_d,psi_d1(end),deg2rad(-20));
[psi_d3,dot_psi_d3,ddot_psi_d3,dddot_psi_d3]=rectilinear_path_convex(s3_d,dot_s3_d,ddot_s3_d,dddot_s3_d,psi_d2(end),deg2rad(270));

psi_d=[psi_d1 psi_d2 psi_d3];
dot_psi_d=[dot_psi_d1 dot_psi_d2 dot_psi_d3];
ddot_psi_d=[ddot_psi_d1 ddot_psi_d2 ddot_psi_d3];
dddot_psi_d=[dddot_psi_d1 dddot_psi_d2 dddot_psi_d3];


%% first helix
[p_d1,dot_p_d1,ddot_p_d1,dddot_p_d1]=spiral_path_yz(s1_d,dot_s1_d,ddot_s1_d,dddot_s1_d,[x0,y0,z0],radius1,alfa,d);
%% rectilinear path
[x_d2,dot_x_d2,ddot_x_d2,dddot_x_d2]=rectilinear_path_convex(s2_d,dot_s2_d,ddot_s2_d,dddot_s2_d,p_d1(1,end),p_d1(1,end)+1);
[y_d2,dot_y_d2,ddot_y_d2,dddot_y_d2]=rectilinear_path_convex(s2_d,dot_s2_d,ddot_s2_d,dddot_s2_d,p_d1(2,end),p_d1(2,end)+1);
[z_d2,dot_z_d2,ddot_z_d2,dddot_z_d2]=rectilinear_path_convex(s2_d,dot_s2_d,ddot_s2_d,dddot_s2_d,p_d1(3,end),p_d1(3,end)-1);
%% second helix
[p_d3,dot_p_d3,ddot_p_d3,dddot_p_d3]=spiral_path_xy(s3_d,dot_s3_d,ddot_s3_d,dddot_s3_d,[x_d2(end),y_d2(end),z_d2(end)],radius2,alfa2,-d);

%% complete trajectory
p_d=[p_d1 [x_d2;y_d2;z_d2] p_d3];
dot_p_d=[dot_p_d1 [dot_x_d2;dot_y_d2;dot_z_d2] dot_p_d3];
ddot_p_d=[ddot_p_d1 [ddot_x_d2;ddot_y_d2;ddot_z_d2] ddot_p_d3];
dddot_p_d=[dddot_p_d1 [dddot_x_d2;dddot_y_d2;dddot_z_d2] dddot_p_d3];

time=t;
%data for Simulink
pos_0 = [x0 y0 z0];
lin_vel_0 = [dot_x0 dot_y0 dot_z0];
w_bb_0 = [0 0 0];
csi_d=p_d(1:3,:); dot_csi_d=dot_p_d(1:3,:); ddot_csi_d=ddot_p_d(1:3,:);

%% plots of desired quantities
figure
plot3(p_d1(1,:),p_d1(2,:),p_d1(3,:),'b','LineWidth',2);
set(gca,'ZDir','reverse')
set(gca,'YDir','reverse')
axis('equal')
grid
xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
% %% position
% % Divisione delle colonne della matrice p_d
% p_d_x = p_d(1, :);
% p_d_y = p_d(2, :);
% p_d_z = p_d(3, :);
% 
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = 'Position [m]';
% pdf_name = 'Desired_Position.pdf';
% plot_title = 'Desired Trajectory';
% legend_labels = {'$p_{d_x}$', '$p_{d_y}$', '$p_{d_z}$'};
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot2(t, p_d_x, p_d_y, p_d_z, x_label_latex, y_label_latex, pdf_name, plot_title, legend_labels);
% %% velocità
% % Divisione delle colonne della matrice p_d
% dot_p_d_x = dot_p_d(1, :);
% dot_p_d_y = dot_p_d(2, :);
% dot_p_d_z = dot_p_d(3, :);
% 
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = 'Velocity [m/s]';
% pdf_name = 'Desired_velocities.pdf';
% plot_title = 'Desired Velocity';
% legend_labels = {'$\dot{p}_{d_x}$', '$\dot{p}_{d_y}$', '$\dot{p}_{d_z}$'};
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot2(t, dot_p_d_x, dot_p_d_y, dot_p_d_z, x_label_latex, y_label_latex, pdf_name, plot_title, legend_labels);
% 
% %% accelerazioni
% % Divisione delle colonne della matrice p_d
% ddot_p_d_x = ddot_p_d(1, :);
% ddot_p_d_y = ddot_p_d(2, :);
% ddot_p_d_z = ddot_p_d(3, :);
% 
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = 'Accelerations [m/s^2]';
% pdf_name = 'Desired_accelerations.pdf';
% plot_title = 'Desired Accelerations';
% legend_labels = {'$\ddot{p}_{d_x}$', '$\ddot{p}_{d_y}$', '$\ddot{p}_{d_z}$'};
% 
% % Chiamata alla funzione personal_plot
%  h = personal_plot2(t, ddot_p_d_x, ddot_p_d_y, ddot_p_d_z, x_label_latex, y_label_latex, pdf_name, plot_title, legend_labels);
% 
% %% jerk
% % Divisione delle colonne della matrice p_d
% dddot_p_d_x = dddot_p_d(1, :);
% dddot_p_d_y = dddot_p_d(2, :);
% dddot_p_d_z = dddot_p_d(3, :);
% 
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = 'Jerk [m/s^3]';
% pdf_name = 'Desired_jerk.pdf';
% plot_title = 'Desired Jerk';
% legend_labels = {'$p^{(3)}_{d_x}$', '$p^{(3)}_{d_y}$', '$p^{(3)}_{d_z}$'};
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot2(t, dddot_p_d_x, dddot_p_d_y, dddot_p_d_z, x_label_latex, y_label_latex, pdf_name, plot_title, legend_labels);
% 
% 
% %% yaw
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = '$\psi$ [rad]';
% pdf_name = 'Desired_Yaw.pdf';
% plot_title = 'Desired Yaw';
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot(t,psi_d, x_label_latex, y_label_latex, pdf_name, plot_title);
% %% yaw vel
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = '$\dot{\psi}$ [rad/s]';
% pdf_name = 'Desired_Yaw_vel.pdf';
% plot_title = 'Desired Yaw Velocity';
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot(t,dot_psi_d, x_label_latex, y_label_latex, pdf_name, plot_title);
% %% yaw acc
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = '$\ddot{\psi} [rad/s^2]$';
% pdf_name = 'Desired_Yaw_acc.pdf';
% plot_title = 'Desired Yaw Acceleration';
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot(t,ddot_psi_d, x_label_latex, y_label_latex, pdf_name, plot_title);
% %% yaw jerk
% % Definizione delle etichette degli assi e del titolo
% x_label_latex = 'time [s]';
% y_label_latex = '$\psi^{(3)} [rad/s^3]$';
% pdf_name = 'Desired_Yaw_jerk.pdf';
% plot_title = 'Desired Yaw Jerk';
% 
% % Chiamata alla funzione personal_plot
% h = personal_plot(t,dddot_psi_d, x_label_latex, y_label_latex, pdf_name, plot_title);