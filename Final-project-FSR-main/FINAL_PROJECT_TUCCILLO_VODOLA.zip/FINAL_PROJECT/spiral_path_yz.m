function [p_d,dot_p_d,ddot_p_d,dddot_p_d]=spiral_path_yz(s_d,dot_s_d,ddot_s_d,dddot_s_d,p0,radius,alfa,d)
  %center position
  p0x = p0(1);
  p0y = p0(2)+radius;
  p0z = p0(3);

  %POSIZIONE
  p_dx =(1-s_d)*p0x+s_d*(p0x+d);
  p_dy= p0y - radius*cos(alfa*s_d);
  p_dz= p0z - radius*sin(alfa*s_d);
  p_d=[p_dx;p_dy;p_dz];

  %VELOCITA
  dot_p_dx = d*dot_s_d;
  dot_p_dy = radius.*(alfa).*dot_s_d.*sin(alfa.*s_d);
  dot_p_dz = -radius.*(alfa).*dot_s_d.*cos(alfa.*s_d);
  dot_p_d=[dot_p_dx;dot_p_dy;dot_p_dz];
 
  %ACCELERAZIONE
  ddot_p_dx = d*ddot_s_d;
  ddot_p_dy = radius.*(alfa).*(dot_s_d.*dot_s_d.*alfa.*cos(alfa.*s_d)+ddot_s_d.*sin(2*alfa*s_d));
  ddot_p_dz = -radius.*(alfa).*(-dot_s_d.*dot_s_d.*alfa.*sin(alfa.*s_d)+ddot_s_d.*cos(2*alfa*s_d));
  ddot_p_d=[ddot_p_dx;ddot_p_dy;ddot_p_dz];

  %JERK
  dddot_p_dx = d*dddot_s_d;
  dddot_p_dy=radius.*alfa.*(2.*dot_s_d.*ddot_s_d.*alfa.*cos(alfa.*s_d)-alfa^2.*dot_s_d.^3.*sin(alfa.*s_d)...
      +dddot_s_d.*sin(2.*alfa.*s_d)+ddot_s_d.*2.*alfa.*dot_s_d.*cos(2.*alfa.*s_d));

  dddot_p_dz=-radius.*alfa.*(-2.*dot_s_d.*ddot_s_d.*alfa.*sin(alfa.*s_d)-dot_s_d.^3.*alfa^2.*cos(alfa.*s_d)...
      +dddot_s_d.*cos(2.*alfa.*s_d)-ddot_s_d.*2.*alfa.*dot_s_d.*sin(2.*alfa.*s_d));

  dddot_p_d=[dddot_p_dx;dddot_p_dy;dddot_p_dz];

end